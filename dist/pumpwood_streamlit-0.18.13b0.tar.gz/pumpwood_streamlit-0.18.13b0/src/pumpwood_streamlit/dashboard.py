"""Dashboard class to use as base from Pumpwood Streamlit Dashboards."""

import os
import traceback
import streamlit as st
from abc import ABC, abstractmethod
from pumpwood_communication.microservices import PumpWoodMicroService
from pumpwood_communication.exceptions import PumpWoodException
from pumpwood_streamlit.authentication import StreamlitAuthenticationABC
from pumpwood_streamlit.exceptions import (
    PumpwoodStreamlitUnauthorizedException,
)


class PumpwoodStreamlitDashboard(ABC):
    """Abstract Class to facilitate criation of Streamlit Dashboards."""

    @property
    @abstractmethod
    def streamlit_auth(self) -> StreamlitAuthenticationABC:
        """Object of sub-class StreamlitAuthenticationABC."""
        pass

    @property
    @abstractmethod
    def microservice(self) -> PumpWoodMicroService:
        """Object of PumpWoodMicroService."""
        pass

    def authentication_error_page(self) -> None:
        """Render the page shown when authentication fails.

        Called by ``run()`` when ``streamlit_auth.check_if_logged()``
        raises ``PumpwoodStreamlitUnauthorizedException``.

        Example:
        ```python
        st.title(
            'User token is invalid, log in again to refresh token.')
        ```
        """
        st.title("User token is invalid, log in again to refresh token.")

    def error_handler(self, exception: PumpWoodException) -> bool:
        """Render a default error page for PumpWood exceptions.

        Args:
            exception (PumpWoodException):
                Exception raised during dashboard execution.

        Returns:
            bool:
                Always returns False (reserved for future use).
        """
        exception_dict = exception.to_dict()
        tb = traceback.format_exc()
        with st.container():
            st.header("Error when running dashboard")
            st.text(exception_dict["message"])

        with st.container():
            with st.expander("Debug traceback"):
                st.write(tb)

    def run(self) -> None:
        """Render Streamlit dashboard.

        Entry point for ``app.py``. Sets page config and styles,
        validates authentication via ``streamlit_auth.check_if_logged()``,
        then calls ``main_view()``. Catches
        ``PumpwoodStreamlitUnauthorizedException`` and
        ``PumpWoodException`` with default handlers.

        Should rarely be overridden. If overridden, call
        ``self.streamlit_auth.check_if_logged()`` before
        ``main_view()``.

        Example of an app.py:
        ```
        from dashboard import Dashboard

        dash_obj = Dashboard()
        dash_obj.run()
        ```
        """
        # Set page configuration
        self.set_page_config()
        self.set_style()

        # Render main Dashboard View, if any PumpwoodStreamlitException
        # errors were raised, them treat them and return a default
        # error page.
        try:
            self.streamlit_auth.check_if_logged()
            self.main_view()
        except PumpwoodStreamlitUnauthorizedException:
            self.authentication_error_page()
        except PumpWoodException as e:
            self.error_handler(exception=e)
        except Exception as e:
            raise e

    @abstractmethod
    def set_page_config(self) -> None:
        """Set page config, must be implemented.

        Exemple:
        ```python
        st.set_page_config(
            page_title="US Population Dashboard",
            page_icon="🏂",
            layout="wide",
            initial_sidebar_state="expanded")
        ```
        """
        msg = "'set_page_config' function must be implemented"
        raise NotImplementedError(msg)

    def set_style(self) -> None:
        """Load CSS files into the dashboard.

        Reads all ``.css`` files from the directory set by
        ``PUMPWOOD_DASHBOARD__STYLES_DIR`` (default:
        ``static/styles``) and injects them via ``st.markdown``.
        """
        PUMPWOOD_DASHBOARD__STYLES_DIR = os.getenv(
            "PUMPWOOD_DASHBOARD__STYLES_DIR", "static/styles"
        )
        all_styles = []
        for file in os.listdir(PUMPWOOD_DASHBOARD__STYLES_DIR):
            if file.endswith(".css"):
                file_path = os.path.join(PUMPWOOD_DASHBOARD__STYLES_DIR, file)
                file_break = (
                    "\n/* ### Styles from file [{file}] ### */"
                ).format(file=file)
                all_styles.append(file_break)
                with open(file_path, "r") as file:
                    all_styles.append(file.read())
        css = "\n".join(all_styles)
        st.markdown(
            "<style> {css} </style>".format(css=css), unsafe_allow_html=True
        )

    @abstractmethod
    def main_view(self) -> None:
        """Render main dashboard view.

        Exemple:
        ```python
        st.set_page_config(
            page_title="US Population Dashboard",
            page_icon="🏂",
            layout="wide",
            initial_sidebar_state="expanded")
        ```
        """
        msg = "'main_view' function must be implemented"
        raise NotImplementedError(msg)
